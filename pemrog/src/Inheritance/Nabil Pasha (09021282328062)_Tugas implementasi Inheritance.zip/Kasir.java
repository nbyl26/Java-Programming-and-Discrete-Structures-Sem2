package Inheritance;

public class Kasir extends Pegawai {
    public Kasir(String nama, int idPegawai){
        super(nama, 1.2, idPegawai, "Melakukan transaksi dengan pembeli");
    }
}

