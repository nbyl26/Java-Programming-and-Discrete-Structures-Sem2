package Inheritance;

public class Pelayan extends Pegawai{
    public Pelayan(String nama, int idPegawai){
        super(nama, 1.0, idPegawai, "Melayani dan menyajikan pesanan pembeli");
    }
}

