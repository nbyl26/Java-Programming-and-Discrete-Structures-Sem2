package Inheritance;

public class Koki extends Pegawai {
    public Koki(String nama, int idPegawai){
        super(nama, 2.0, idPegawai, "Memasak makanan dan membuat minuman");
    }
}

