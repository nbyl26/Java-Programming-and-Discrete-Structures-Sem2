package Inheritance;

public class Satpam extends Pegawai{
    public Satpam(String nama, int idPegawai){
        super(nama, 1.0, idPegawai, "Menjaga keamanan didalam dan diluar franchise" );
    }
}

