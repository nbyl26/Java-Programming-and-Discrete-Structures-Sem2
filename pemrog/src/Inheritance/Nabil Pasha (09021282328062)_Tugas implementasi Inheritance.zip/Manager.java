package Inheritance;

public class Manager extends Pegawai {
    public Manager(String nama, int idPegawai){
        super(nama, 7.0, idPegawai, "Melakukan manajemen untuk franchise");
    }
}

